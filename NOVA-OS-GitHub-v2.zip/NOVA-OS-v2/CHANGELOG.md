# Changelog

## 2.0.0 — Mega Update

- Nova interface web responsiva inspirada no macOS Sonoma.
- API local para indicadores de memória, armazenamento, processos, carga média e ferramentas instaladas.
- Inicializador de sessão XFCE com splash no terminal.
- DevKit com exemplos C, Rust, JavaScript e TypeScript.
- Scripts de diagnóstico, aparência opcional, armazenamento e testes.
- Documentação de instalação e limitações atualizada.

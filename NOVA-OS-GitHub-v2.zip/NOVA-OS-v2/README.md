# ✦ NOVA OS 2.0 — Sonoma Workspace

**Um ambiente desktop experimental para Android**, desenvolvido para Termux + Termux:X11 + XFCE, com visual inspirado no macOS Sonoma e um pequeno painel web local.

> **Importante:** NOVA OS não é um sistema operacional independente, não substitui Android e não altera o bootloader/kernel. É uma camada de ambiente gráfico e ferramentas executada no espaço de usuário do Termux. O pacote foi preparado e validado estaticamente neste projeto, mas **não foi executado no Galaxy Tab A11**. Pacotes gráficos e permissões podem variar conforme a origem/versão do Termux.

## ✨ Novidades da versão 2.0

- Interface web responsiva com identidade visual Sonoma: transparências, gradientes, cartões e navegação.
- Central de Controle para RAM, armazenamento, carga média de CPU e processos visíveis.
- Painel de ferramentas que detecta C/Clang, Rust/Cargo, Node.js, npm, TypeScript, Git e Python.
- Cartões de acesso para Thunar, Terminal, Configurações XFCE, rede e processos.
- Inicializador de sessão XFCE com tela de inicialização no terminal.
- DevKit com exemplos executáveis de C, Rust, JavaScript e TypeScript.
- Relatório de armazenamento, documentação de diagnóstico e testes automatizados básicos.
- Servidor do painel limitado a `127.0.0.1`, sem endpoint para executar comandos arbitrários.

## 📱 Requisitos

- Samsung Galaxy Tab A11, Android 16 e 4 GB de RAM são o alvo de desenvolvimento, não uma alegação de teste concluído.
- Termux e Termux:X11 instalados e abertos ao menos uma vez.
- Instale Termux e Termux:X11 de fontes compatíveis entre si. Não misture APKs com assinaturas diferentes.
- Internet para baixar os pacotes.
- Espaço livre recomendado: **1–2 GB ou mais**, dependendo de XFCE, compiladores e caches. O consumo real deve ser medido no tablet.

## 🚀 Instalação no Termux

### Método A — ZIP

1. Baixe e extraia `NOVA-OS-GitHub-v2.zip` usando o gerenciador de arquivos do Android.
2. Abra o Termux e permita acesso aos arquivos, se necessário:

   ```bash
   termux-setup-storage
   ```

3. Entre na pasta extraída. Exemplo se ela estiver em Downloads (ajuste o nome/caminho conforme onde extraiu):

   ```bash
   cd ~/storage/downloads/NOVA-OS-v2
   ```

4. Rode o instalador:

   ```bash
   bash install.sh
   ```

5. Adicione os atalhos do NOVA OS ao PATH da sessão atual:

   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```

   Para deixar permanente no Bash:

   ```bash
   echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
   source ~/.bashrc
   ```

6. Abra Termux:X11 manualmente pelo menos uma vez e inicie o desktop:

   ```bash
   nova
   ```

### Método B — GitHub

Depois de criar o repositório `NOVA-OS` e enviar os arquivos, use:

```bash
pkg update
pkg install git
 git clone https://github.com/SEU-USUARIO/NOVA-OS.git
cd NOVA-OS
bash install.sh
export PATH="$HOME/.local/bin:$PATH"
nova
```

Substitua `SEU-USUARIO` pelo nome real da sua conta. Não publique tokens ou arquivos pessoais.

## 🖥️ Abrir a Central de Controle

O painel web é um processo separado do desktop XFCE. Abra outro terminal do Termux e execute:

```bash
nova-control
```

No navegador do próprio tablet, acesse:

```text
http://127.0.0.1:8765
```

Para encerrar o servidor, pressione `Ctrl+C` no terminal onde ele está rodando. Para executar sem instalar os atalhos:

```bash
python apps/server.py
```

O servidor escuta apenas em `127.0.0.1`, não em todos os endereços da rede. O painel web é uma interface separada e não é automaticamente embutida como janela nativa do XFCE.

## 🧰 DevKit: C, Rust, JavaScript e TypeScript

O instalador tenta preparar Clang, Rust/Cargo, Node.js e npm. Também tenta instalar TypeScript localmente no diretório do projeto. Confirme o estado das ferramentas:

```bash
bash scripts/devkit.sh status
```

Execute exemplos individuais:

```bash
bash scripts/devkit.sh c
bash scripts/devkit.sh rust
bash scripts/devkit.sh js
bash scripts/devkit.sh ts
```

Se algum pacote não estiver disponível na versão atual do Termux, procure-o com `pkg search nome-do-pacote`. As linguagens **não ficam “integradas dentro do shell”**: o shell chama cada compilador/runtime de forma independente, que é a arquitetura correta.

## 🎨 Aparência inspirada no Sonoma

O painel web tem estilo próprio inspirado no macOS Sonoma. A sessão XFCE continua usando os temas e painéis instalados no Termux. Depois de iniciar XFCE, pode testar ajustes cosméticos opcionais:

```bash
bash scripts/sonoma-session.sh
```

A disponibilidade de temas e configurações depende dos pacotes instalados. O script não instala temas de terceiros nem altera o Android. Para personalização manual, abra **Configurações > Aparência**, **Gerenciador de janelas** e **Painel** no XFCE.

## 📊 Medir o armazenamento ocupado

No diretório do projeto:

```bash
bash scripts/storage-report.sh
```

Ou rode comandos individuais:

```bash
du -sh .
df -h "$HOME"
du -h -d 1 "$HOME" 2>/dev/null | sort -h
```

O tamanho do ZIP é diferente do espaço instalado: pacotes, compiladores, caches e dependências aumentam o consumo. Não há como saber o consumo real do tablet sem executar a medição no próprio aparelho.

## 🧪 Testes e diagnóstico

No computador ou Termux com Python 3:

```bash
python -m unittest discover -s tests -v
bash -n install.sh nova.sh scripts/*.sh
python -m py_compile apps/server.py apps/control.py
```

Se a tela ficar preta, confira `docs/TROUBLESHOOTING.md`. É importante instalar Termux e Termux:X11 de fontes compatíveis. A disponibilidade dos pacotes XFCE pode variar entre repositórios e versões.

## 📁 Estrutura

```text
NOVA-OS-v2/
├── apps/                  # servidor e entrada do painel
├── web/                   # HTML, CSS e JavaScript
├── scripts/               # DevKit, aparência e armazenamento
├── src/c/                 # exemplo C
├── src/rust/              # exemplo Rust/Cargo
├── src/typescript/        # exemplo TypeScript
├── tests/                 # testes automatizados básicos
├── docs/                  # desenvolvimento e solução de problemas
├── install.sh             # instalador Termux
├── nova.sh                # inicia Termux:X11 + XFCE
├── VERSION
└── README.md
```

## ⚠️ Limitações conhecidas

- Não é bootável nem substitui Android.
- Não exige root e não contorna as proteções do Android.
- Métricas de hardware dependem do que Android/Termux expõem. A carga apresentada é a média de carga do sistema, **não uma porcentagem de CPU**.
- A detecção de rede é informativa; o Termux pode precisar do complemento Termux:API para certos dados de Wi-Fi.
- A loja é um catálogo/atalho informativo nesta versão, não um repositório gráfico que instala apps por um clique.
- O painel web abre no navegador e não está embutido numa janela nativa do XFCE.
- Não foi possível validar a instalação no tablet físico nesta sessão. Teste primeiro e guarde backup dos seus arquivos.

## 📤 Publicar no GitHub

1. Crie um repositório vazio chamado `NOVA-OS` no GitHub.
2. No Termux, dentro da pasta do projeto:

   ```bash
   git init
   git add .
   git commit -m "NOVA OS 2.0: Sonoma workspace and DevKit"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/NOVA-OS.git
   git push -u origin main
   ```

3. Troque `SEU-USUARIO` pelo seu nome de usuário. Se o remote já existir, use `git remote set-url origin URL` em vez de adicionar novamente.

## Licença

MIT. Veja `LICENSE`.

#!/usr/bin/env python3
"""Compatibility entry point for the NOVA OS Control Center."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name('server.py')), run_name='__main__')

#!/usr/bin/env python3
"""NOVA OS local dashboard server. Binds only to loopback; no external dependencies."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json, os, shutil, subprocess, time
ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'web'
PORT = int(os.environ.get('NOVA_PORT', '8765'))

def read_text(path):
    try: return Path(path).read_text(errors='replace')
    except (OSError, PermissionError): return ''

def command(*args):
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=2, check=False).stdout.strip()
    except (OSError, subprocess.SubprocessError): return ''

def status():
    mem = {}
    for line in read_text('/proc/meminfo').splitlines():
        parts = line.replace(':','').split()
        if len(parts) >= 2:
            try: mem[parts[0]] = int(parts[1]) * 1024
            except ValueError: pass
    total, avail = mem.get('MemTotal', 0), mem.get('MemAvailable', mem.get('MemFree', 0))
    storage = shutil.disk_usage(Path.home())
    cpu = 'Indisponível'
    stat = read_text('/proc/loadavg').split()
    if stat: cpu = stat[0] + ' (carga média)'
    processes = []
    proc = Path('/proc')
    try:
        for p in proc.iterdir():
            if p.name.isdigit():
                name = read_text(p / 'comm').strip()
                if name: processes.append({'pid': int(p.name), 'name': name})
    except OSError: pass
    processes.sort(key=lambda x: x['name'].lower())
    return {'time': time.strftime('%H:%M:%S'), 'cpu_load': cpu,
            'ram_total': total, 'ram_available': avail,
            'ram_used': max(0, total-avail), 'storage_total': storage.total,
            'storage_used': storage.used, 'storage_free': storage.free,
            'process_count': len(processes), 'processes': processes[:100],
            'network': {'termux_wifi': bool(shutil.which('termux-wifi-connectioninfo')),
                        'ip': command('sh','-lc',"ip -brief addr 2>/dev/null | head -8") or 'Informação de IP indisponível'},
            'tools': {n: bool(shutil.which(n)) for n in ['clang','rustc','cargo','node','npm','tsc','git','python']}}

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(WEB), **kwargs)
    def do_GET(self):
        if self.path == '/api/status':
            payload = json.dumps(status()).encode()
            self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload)
        else:
            if self.path == '/': self.path = '/index.html'
            super().do_GET()
    def log_message(self, fmt, *args): pass

if __name__ == '__main__':
    print(f'NOVA OS dashboard: http://127.0.0.1:{PORT}')
    try: ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
    except KeyboardInterrupt: print('\nNOVA OS encerrado.')

# Desenvolvimento do NOVA OS 2.0

## Arquitetura

- `nova.sh`: inicializa a sessão Termux:X11 e XFCE.
- `apps/server.py`: servidor HTTP local sem dependências de terceiros; API `/api/status` e arquivos web. Escuta apenas em `127.0.0.1`.
- `web/`: interface HTML/CSS/JavaScript responsiva inspirada no macOS Sonoma.
- `scripts/devkit.sh`: executa amostras em C, Rust, JavaScript e TypeScript.
- `scripts/storage-report.sh`: estima espaço usado pelo projeto e pelo HOME do Termux.

## Executar painel sem XFCE

```bash
python apps/server.py
```

Abra `http://127.0.0.1:8765` no navegador do mesmo dispositivo. Use `NOVA_PORT=8766 python apps/server.py` para mudar a porta.

## DevKit

```bash
bash scripts/devkit.sh status
bash scripts/devkit.sh c
bash scripts/devkit.sh rust
bash scripts/devkit.sh js
bash scripts/devkit.sh ts
```

O TypeScript requer que o compilador esteja instalado. `install.sh` tenta instalar TypeScript localmente em `src/typescript` via npm. Os compiladores são ferramentas independentes, não linguagens embutidas no Bash.

## Testes locais

```bash
python -m unittest discover -s tests -v
bash -n install.sh nova.sh scripts/*.sh
python -m py_compile apps/server.py
```

## Princípios

- Sem root e sem alterações ao sistema Android.
- O servidor HTTP escuta apenas em loopback.
- Não execute comandos recebidos pela interface web.
- Instalação de pacotes só via scripts explícitos do Termux e com confirmação do utilizador.

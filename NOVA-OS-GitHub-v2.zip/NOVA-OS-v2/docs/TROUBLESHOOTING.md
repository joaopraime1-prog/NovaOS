# Solução de problemas

- **Tela preta no Termux:X11:** abra o app Termux:X11 manualmente, depois rode `nova`. Verifique se o app e os pacotes Termux foram instalados da mesma origem/assinatura.
- **`startxfce4: command not found`:** rode `pkg update && pkg install xfce4` e consulte `pkg search xfce4` se o pacote não estiver disponível.
- **`termux-x11` não encontrado:** instale Termux:X11 e o pacote cliente compatível com os repositórios atuais do Termux.
- **Painel web não abre:** execute `nova-control` em outro terminal e acesse `http://127.0.0.1:8765`. O servidor fica limitado ao loopback e não deve ser acessível pela rede local.
- **Dados de CPU/RAM incompletos:** Android restringe métricas de hardware sem root; o painel usa dados expostos pelo `/proc` e pode mostrar carga média em vez de porcentagem de CPU.
- **Rede sem detalhes:** `ip` e `termux-wifi-connectioninfo` podem não estar disponíveis ou podem exigir o complemento Termux:API e permissões Android.
- **Instalação parcial:** leia a mensagem do `pkg`, execute `pkg update`, pesquise o pacote com `pkg search nome` e consulte a documentação oficial do Termux/X11.
- **Pouco armazenamento:** execute `bash scripts/storage-report.sh`. Não apague cache ou diretórios de pacotes manualmente sem saber o que são.

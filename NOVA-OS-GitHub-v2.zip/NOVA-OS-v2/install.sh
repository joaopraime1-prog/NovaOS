#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
BIN="$PREFIX/bin"
if [[ -z "${PREFIX:-}" && ! -d "$PREFIX" ]]; then echo 'Execute este instalador dentro do Termux.' >&2; exit 1; fi
command -v pkg >/dev/null || { echo 'Comando pkg não encontrado. Este instalador é para Termux.' >&2; exit 1; }
printf '\n✦ NOVA OS 2.0 · instalador\nProjeto: %s\n' "$ROOT"
pkg update
pkg install -y python git clang rust nodejs-lts coreutils procps termux-tools
# Pacotes gráficos opcionais podem ter nomes/disponibilidade diferentes por repositório.
if ! command -v termux-x11 >/dev/null 2>&1; then pkg install -y x11-repo; pkg install -y termux-x11-nightly || pkg install -y termux-x11; fi
pkg install -y xfce4 thunar xfce4-terminal xfce4-settings mousepad dbus || {
  echo 'Alguns pacotes XFCE não foram instalados. Consulte docs/TROUBLESHOOTING.md e rode pkg search xfce4.' >&2
}
# TypeScript é instalado localmente pelo npm quando possível, sem alterar globalmente o sistema.
if command -v npm >/dev/null 2>&1; then
  mkdir -p "$ROOT/src/typescript"
  (cd "$ROOT/src/typescript" && npm init -y >/dev/null 2>&1 && npm install --save-dev typescript) || echo 'TypeScript opcional não instalado; veja README.'
fi
mkdir -p "$HOME/.local/bin" "$HOME/.config/autostart"
cat > "$HOME/.local/bin/nova" <<EOF
#!/data/data/com.termux/files/usr/bin/bash
exec bash "$ROOT/nova.sh" "\$@"
EOF
cat > "$HOME/.local/bin/nova-control" <<EOF
#!/data/data/com.termux/files/usr/bin/bash
exec python "$ROOT/apps/server.py"
EOF
chmod +x "$HOME/.local/bin/nova" "$HOME/.local/bin/nova-control" "$ROOT/nova.sh" "$ROOT/scripts/storage-report.sh"
case ":$PATH:" in *":$HOME/.local/bin:"*) ;; *) echo 'Adicione isto ao ~/.bashrc: export PATH="$HOME/.local/bin:$PATH"';; esac
printf '\nInstalação concluída.\n1) Abra Termux:X11 pelo menos uma vez.\n2) Execute: export PATH="$HOME/.local/bin:$PATH"\n3) Inicie o desktop: nova\n4) Painel web: nova-control (abra http://127.0.0.1:8765 no navegador)\n'

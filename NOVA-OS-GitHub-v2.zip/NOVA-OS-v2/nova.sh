#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export DISPLAY="${DISPLAY:-:0}"
export XDG_RUNTIME_DIR="${TMPDIR:-/tmp}/nova-runtime"
mkdir -p "$XDG_RUNTIME_DIR"; chmod 700 "$XDG_RUNTIME_DIR"
clear || true
printf '\033[1;36m\n   ✦  N O V A   O S\033[0m\n   \\  macOS-inspired Linux workspace\n\n   Preparando sessão gráfica…\n'
if ! command -v termux-x11 >/dev/null 2>&1; then echo 'termux-x11 não encontrado. Instale Termux:X11 e o pacote correspondente.' >&2; exit 1; fi
# A sessão X11 pode já estar aberta; não a reinicie à força.
if ! pgrep -f 'termux.x11' >/dev/null 2>&1; then termux-x11 "$DISPLAY" >/dev/null 2>&1 & sleep 2; fi
if command -v am >/dev/null 2>&1; then am start --user 0 -n com.termux.x11/.MainActivity >/dev/null 2>&1 || true; fi
export PULSE_SERVER="${PULSE_SERVER:-127.0.0.1}"
if command -v dbus-launch >/dev/null 2>&1; then exec dbus-launch --exit-with-session startxfce4; elif command -v dbus-run-session >/dev/null 2>&1; then exec dbus-run-session startxfce4; else exec startxfce4; fi

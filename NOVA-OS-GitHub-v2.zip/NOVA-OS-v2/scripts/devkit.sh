#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
case "${1:-status}" in
  status)
    for tool in clang rustc cargo node npm; do if command -v "$tool" >/dev/null 2>&1; then printf '✓ %-8s %s\n' "$tool" "$($tool --version 2>/dev/null | head -1)"; else printf '· %-8s não instalado\n' "$tool"; fi; done
    if [[ -x "$ROOT/src/typescript/node_modules/.bin/tsc" ]]; then "$ROOT/src/typescript/node_modules/.bin/tsc" --version; elif command -v tsc >/dev/null 2>&1; then tsc --version; else echo '· TypeScript não instalado'; fi
    ;;
  c) command -v clang >/dev/null || { echo 'Instale com: pkg install clang'; exit 1; }; clang "$ROOT/src/c/hello.c" -o "$ROOT/src/c/hello"; "$ROOT/src/c/hello" ;;
  rust) command -v cargo >/dev/null || { echo 'Instale com: pkg install rust'; exit 1; }; cargo run --manifest-path "$ROOT/src/rust/Cargo.toml" ;;
  js) command -v node >/dev/null || { echo 'Instale com: pkg install nodejs-lts'; exit 1; }; node -e 'console.log("NOVA OS DevKit: JavaScript está funcionando.")' ;;
  ts) TSC="$ROOT/src/typescript/node_modules/.bin/tsc"; [[ -x "$TSC" ]] || TSC="$(command -v tsc || true)"; [[ -n "$TSC" ]] || { echo 'TypeScript ausente. Entre em src/typescript e execute npm install.'; exit 1; }; "$TSC" "$ROOT/src/typescript/hello.ts" --target ES2020 --module commonjs --outDir "$ROOT/src/typescript/dist"; node "$ROOT/src/typescript/dist/hello.js" ;;
  *) echo 'Uso: bash scripts/devkit.sh {status|c|rust|js|ts}'; exit 2;;
esac

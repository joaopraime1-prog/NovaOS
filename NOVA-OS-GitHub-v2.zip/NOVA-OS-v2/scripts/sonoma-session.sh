#!/data/data/com.termux/files/usr/bin/bash
# Configurações cosméticas seguras e opcionais para uma sessão XFCE já instalada.
set -u
command -v xfconf-query >/dev/null || { echo 'xfconf-query não encontrado; entre numa sessão XFCE primeiro.'; exit 1; }
# Tema e ícones variam entre repositórios. Só define valores se o tema existir.
if [[ -d "$PREFIX/share/themes/Adwaita-dark" ]]; then xfconf-query -c xsettings -p /Net/ThemeName -s 'Adwaita-dark' 2>/dev/null || true; fi
xfconf-query -c xsettings -p /Gtk/CursorThemeName -s 'Adwaita' 2>/dev/null || true
xfconf-query -c xfwm4 -p /general/title_alignment -s 'center' 2>/dev/null || true
echo 'Preferências cosméticas aplicadas quando suportadas. Para reverter, use Configurações > Gerenciador de janelas/Aparência.'

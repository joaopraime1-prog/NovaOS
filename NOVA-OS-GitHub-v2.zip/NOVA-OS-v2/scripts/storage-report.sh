#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
printf 'NOVA OS · relatório de armazenamento\n\nProjeto: %s\n' "$ROOT"
du -sh "$ROOT" 2>/dev/null || true
printf '\nArmazenamento do HOME do Termux:\n'; df -h "$HOME" 2>/dev/null || true
printf '\nPastas maiores dentro do HOME (pode demorar):\n'; du -h -d 1 "$HOME" 2>/dev/null | sort -h | tail -15 || true

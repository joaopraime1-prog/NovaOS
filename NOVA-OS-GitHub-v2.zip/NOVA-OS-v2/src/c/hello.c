#include <stdio.h>
int main(void) { puts("NOVA OS DevKit: C/Clang pronto para experimentar."); return 0; }

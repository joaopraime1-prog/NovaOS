fn main() {
    println!("NOVA OS DevKit: Rust/Cargo pronto para experimentar.");
}

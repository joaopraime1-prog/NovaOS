const message: string = "NOVA OS DevKit: TypeScript está funcionando.";
console.log(message);

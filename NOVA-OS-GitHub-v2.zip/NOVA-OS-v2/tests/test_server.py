import importlib.util, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('nova_server', ROOT/'apps'/'server.py')
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
class DashboardTests(unittest.TestCase):
    def test_status_schema(self):
        d = mod.status()
        for key in ['time','cpu_load','ram_total','ram_available','storage_total','storage_used','storage_free','process_count','processes','network','tools']:
            self.assertIn(key, d)
        self.assertIsInstance(d['processes'], list)
        self.assertIsInstance(d['tools'], dict)
    def test_dashboard_assets(self):
        self.assertTrue((ROOT/'web'/'index.html').is_file())
        self.assertTrue((ROOT/'web'/'style.css').is_file())
        self.assertTrue((ROOT/'web'/'app.js').is_file())
if __name__ == '__main__': unittest.main()

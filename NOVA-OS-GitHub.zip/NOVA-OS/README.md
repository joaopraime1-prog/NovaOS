# NOVA OS 🌌

**NOVA OS** é um ambiente desktop experimental para Android, desenvolvido no **Samsung Galaxy Tab A11** com **Termux + Termux:X11 + XFCE**. A proposta visual é inspirada no macOS, sem substituir nem modificar o Android.

> **Estado do projeto:** protótipo em desenvolvimento. Este repositório fornece uma base instalável e documentada. Ele não é um sistema operacional independente nem substitui o Android: é uma sessão Linux gráfica executada dentro do Termux.

## Recursos incluídos

- Inicializador `nova` para abrir Termux:X11 e XFCE.
- Central de Controle com CPU, RAM e armazenamento.
- Atualização automática dos indicadores enquanto a janela estiver aberta.
- Scripts de instalação, inicialização e diagnóstico de armazenamento.
- Instruções para publicar no GitHub.

## Requisitos

- Android 13 ou superior (testado como alvo no Galaxy Tab A11 com Android 16).
- Aplicativos Termux e Termux:X11 instalados. Prefira instalar ambos por fontes compatíveis entre si, como F-Droid/GitHub oficial do projeto; evite misturar assinaturas de lojas diferentes.
- Conexão à internet na primeira instalação.
- Espaço livre: reserve **pelo menos 1–2 GB** para pacotes e dependências. O consumo real varia e deve ser medido no próprio tablet.

## Instalação rápida

1. Instale e abra **Termux** e **Termux:X11** pelo menos uma vez.
2. Extraia este ZIP para uma pasta acessível no tablet, ou clone o repositório no Termux.
3. No Termux, execute:

```bash
pkg update && pkg upgrade
pkg install git
# Se o projeto já estiver no GitHub:
git clone https://github.com/SEU-USUARIO/NOVA-OS.git
cd NOVA-OS
bash install.sh
```

Se estiver usando o ZIP, entre na pasta onde extraiu os arquivos. Se o ZIP estiver em Downloads, habilite o acesso aos arquivos com `termux-setup-storage` e depois use `cd ~/storage/downloads/NOVA-OS` (ajuste o caminho conforme a pasta real).

4. Inicie o ambiente:

```bash
nova
```

Na primeira execução, conceda as permissões solicitadas pelo Android e abra o app Termux:X11 se ele não abrir automaticamente.

## Instalação manual / solução de problemas

O script `install.sh` configura os repositórios e instala os pacotes necessários. Se algum pacote não existir na versão do Termux que você usa, execute `pkg search nome-do-pacote` e consulte a documentação oficial do Termux/X11. Os nomes e a disponibilidade de pacotes podem mudar.

Para verificar o script de inicialização:

```bash
bash -n ~/bin/nova
```

Para testar a interface diretamente:

```bash
python ~/nova-os/apps/control.py
```

Se aparecer `No module named tkinter`, a versão do Python do seu Termux não inclui Tkinter. Não instale pacotes aleatórios de fontes desconhecidas; ajuste a interface para uma biblioteca gráfica disponível no seu ambiente.

## Como funciona

- **Termux** fornece o ambiente Linux em espaço de usuário.
- **Termux:X11** fornece o servidor gráfico X11.
- **XFCE** é o ambiente desktop.
- A Central de Controle lê informações expostas pelo Android/Termux. Sem root, alguns dados de hardware podem estar indisponíveis ou limitados pelo Android.

## Medir o espaço ocupado

O repositório não consegue saber quanto espaço já foi consumido no seu tablet sem executar os comandos no próprio Termux. Para medir:

```bash
# Tamanho do projeto
 du -sh ~/nova-os 2>/dev/null

# Uso do armazenamento onde está o diretório HOME do Termux
 df -h "$HOME"

# Estimativa dos diretórios mais pesados
 du -h -d 1 "$HOME" 2>/dev/null | sort -h
```

Os números medem coisas diferentes: `du` estima o tamanho dos arquivos acessíveis; `df` mostra o uso do sistema de arquivos. Cache, pacotes e dados privados do Android podem fazer os valores divergirem.

## Publicar no GitHub

Crie um repositório vazio chamado `NOVA-OS` no GitHub. No Termux, dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Initial NOVA OS prototype"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOVA-OS.git
git push -u origin main
```

Troque `SEU-USUARIO` pelo seu nome de usuário. Não publique tokens, senhas, arquivos pessoais ou dumps do armazenamento.

## Estrutura

```text
NOVA-OS/
├── apps/
│   └── control.py       # Central de Controle
├── docs/
│   └── DEVELOPMENT.md  # Notas de desenvolvimento
├── scripts/
│   └── storage-report.sh
├── install.sh           # Instala dependências
├── nova.sh              # Inicializa Termux:X11 + XFCE
├── .gitignore
├── LICENSE
└── README.md
```

## Limitações importantes

- Não é um kernel nem um sistema operacional bootável.
- Não concede root nem contorna as proteções do Android.
- Métricas de CPU e RAM podem ser aproximadas ou indisponíveis dependendo das permissões e da versão do Android.
- O consumo real de armazenamento precisa ser medido no dispositivo.

## Licença

MIT. Consulte `LICENSE`.

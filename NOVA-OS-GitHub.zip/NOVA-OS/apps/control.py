#!/usr/bin/env python3
"""NOVA OS Control Center prototype. Requires Python Tkinter and psutil (optional)."""
import os
import shutil
import time
import tkinter as tk
from tkinter import ttk

try:
    import psutil
except ImportError:
    psutil = None

BG = "#11131a"
PANEL = "#1c202b"
TEXT = "#f4f6fb"
MUTED = "#9ba5b7"
ACCENT = "#8b7cff"

class ControlCenter:
    def __init__(self, root):
        self.root = root
        root.title("NOVA OS • Central de Controle")
        root.geometry("720x500")
        root.minsize(560, 420)
        root.configure(bg=BG)
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TProgressbar", troughcolor="#303544", background=ACCENT, bordercolor=PANEL, lightcolor=ACCENT, darkcolor=ACCENT)

        header = tk.Frame(root, bg=BG)
        header.pack(fill="x", padx=24, pady=(22, 14))
        tk.Label(header, text="NOVA", font=("Arial", 24, "bold"), fg=TEXT, bg=BG).pack(anchor="w")
        tk.Label(header, text="CENTRAL DE CONTROLE  /  VISÃO DO SISTEMA", font=("Arial", 9), fg=MUTED, bg=BG).pack(anchor="w", pady=(3, 0))

        self.cards = tk.Frame(root, bg=BG)
        self.cards.pack(fill="both", expand=True, padx=24, pady=4)
        self.labels = {}
        for key, title in [("cpu", "CPU"), ("ram", "MEMÓRIA RAM"), ("disk", "ARMAZENAMENTO")]:
            card = tk.Frame(self.cards, bg=PANEL, padx=18, pady=16, highlightthickness=1, highlightbackground="#303544")
            card.pack(fill="x", pady=7)
            tk.Label(card, text=title, font=("Arial", 10, "bold"), fg=MUTED, bg=PANEL).pack(anchor="w")
            value = tk.Label(card, text="Lendo dados…", font=("Arial", 17, "bold"), fg=TEXT, bg=PANEL)
            value.pack(anchor="w", pady=(7, 8))
            bar = ttk.Progressbar(card, maximum=100, mode="determinate")
            bar.pack(fill="x")
            self.labels[key] = (value, bar)

        self.status = tk.Label(root, text="Inicializando monitoramento…", font=("Arial", 9), fg=MUTED, bg=BG)
        self.status.pack(anchor="w", padx=26, pady=(4, 18))
        self.update_stats()

    def update_stats(self):
        try:
            cpu = psutil.cpu_percent(interval=None) if psutil else None
            ram = psutil.virtual_memory() if psutil else None
            disk = shutil.disk_usage(os.path.expanduser("~"))
            disk_pct = disk.used / disk.total * 100 if disk.total else 0

            self.set_card("cpu", f"{cpu:.0f}% de uso" if cpu is not None else "Indisponível", cpu or 0)
            self.set_card("ram", f"{ram.percent:.0f}% • {ram.used / 1024**3:.1f} / {ram.total / 1024**3:.1f} GB" if ram else "Indisponível", ram.percent if ram else 0)
            self.set_card("disk", f"{disk_pct:.0f}% • {disk.used / 1024**3:.1f} / {disk.total / 1024**3:.1f} GB", disk_pct)
            self.status.config(text=f"Atualizado às {time.strftime('%H:%M:%S')}  •  dados disponíveis no ambiente Termux")
        except Exception as exc:
            self.status.config(text=f"Não foi possível ler todos os dados: {exc}")
        self.root.after(2000, self.update_stats)

    def set_card(self, key, text, percent):
        value, bar = self.labels[key]
        value.config(text=text)
        bar["value"] = max(0, min(100, percent))

if __name__ == "__main__":
    root = tk.Tk()
    ControlCenter(root)
    root.mainloop()

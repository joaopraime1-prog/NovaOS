# Notas de desenvolvimento

## Estado atual

A base inclui um launcher para Termux:X11 + XFCE e um protótipo de Central de Controle. O projeto é um ambiente gráfico em espaço de usuário no Android, não um sistema operacional independente.

## Próximas etapas sugeridas

1. Confirmar a biblioteca GUI realmente disponível no Termux instalado.
2. Adicionar configuração visual persistente e temas XFCE.
3. Adicionar monitoramento de processos, bateria e temperatura apenas quando os dados forem acessíveis sem root.
4. Testar instalação limpa no Galaxy Tab A11 e documentar versões dos pacotes.
5. Medir o tamanho instalado no dispositivo e registrar valores reais no README, sem inventar estimativas.

## Testes básicos

```bash
bash -n install.sh
bash -n nova.sh
python -m py_compile apps/control.py
```

A compilação de Python valida sintaxe, não garante que Tkinter esteja instalado nem que todos os dados do Android sejam expostos.

#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

if [ -z "${PREFIX:-}" ] || [[ "$PREFIX" != /data/data/com.termux/files/usr ]]; then
  echo "Execute este instalador dentro do Termux no Android."
  exit 1
fi

pkg update -y
pkg upgrade -y
pkg install -y x11-repo
pkg update -y
# Os nomes podem variar conforme a versão/repositório do Termux.
pkg install -y python git xfce4 termux-x11-nightly procps coreutils

mkdir -p "$HOME/nova-os/apps" "$HOME/bin"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp -f "$PROJECT_DIR/apps/control.py" "$HOME/nova-os/apps/control.py"
cp -f "$PROJECT_DIR/nova.sh" "$HOME/nova-os/nova.sh"
chmod +x "$HOME/nova-os/nova.sh"
ln -sf "$HOME/nova-os/nova.sh" "$HOME/bin/nova"

case ":$PATH:" in
  *":$HOME/bin:"*) ;;
  *) echo 'export PATH="$HOME/bin:$PATH"' >> "$HOME/.bashrc" ;;
esac

echo
echo "Instalação concluída. Feche e reabra o Termux se o comando nova não for encontrado."
echo "Depois execute: nova"
echo "Se o pacote termux-x11-nightly não estiver disponível, consulte a documentação oficial do Termux:X11."

#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

export DISPLAY="${DISPLAY:-:1}"

if ! command -v termux-x11 >/dev/null 2>&1; then
  echo "Termux:X11 não foi encontrado. Instale o app e o pacote compatível no Termux."
  exit 1
fi

# Inicia o servidor X11 em segundo plano; se já estiver rodando, não falha.
(termux-x11 "$DISPLAY" >/dev/null 2>&1 &) || true
sleep 2

if command -v xfce4-session >/dev/null 2>&1; then
  (xfce4-session >/dev/null 2>&1 &) || true
else
  echo "XFCE não foi encontrado. Execute bash install.sh para instalar as dependências."
  exit 1
fi

if command -v python >/dev/null 2>&1; then
  sleep 3
  python "$HOME/nova-os/apps/control.py" || echo "A Central de Controle não iniciou. Verifique se Tkinter está disponível no Python do Termux."
fi

#!/data/data/com.termux/files/usr/bin/bash
set -eu
PROJECT_DIR="${1:-$HOME/nova-os}"
echo "=== NOVA OS: relatório de armazenamento ==="
echo "Data: $(date)"
echo
echo "--- Espaço do sistema de arquivos do Termux ---"
df -h "$HOME" || true
echo
echo "--- Tamanho do projeto ---"
if [ -d "$PROJECT_DIR" ]; then du -sh "$PROJECT_DIR"; else echo "Projeto não encontrado em: $PROJECT_DIR"; fi
echo
echo "--- Diretórios mais pesados no HOME ---"
du -h -d 1 "$HOME" 2>/dev/null | sort -h | tail -n 20 || true
